from django.apps import AppConfig


class ReadingConfig(AppConfig):
    name = 'reading'
