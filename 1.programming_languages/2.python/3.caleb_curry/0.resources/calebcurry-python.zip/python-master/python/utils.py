def stats_range(data):
    sorted_data = sorted(data)
    return sorted_data[-1] - sorted_data[0]